package at.htlkaindorf.bankaccount.bl;

import java.util.List;

public class ListPointer {
    public static List<Account> list;
}
