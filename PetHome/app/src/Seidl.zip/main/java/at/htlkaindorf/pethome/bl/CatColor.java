package at.htlkaindorf.pethome.bl;

public enum CatColor {
    BLACK, WHITE, CREAM, RED, CINNAMON, FAWN, CHOCOLATE, APRICOT, AMBER;
}
