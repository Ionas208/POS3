package at.htlkaindorf.pethome.bl;

public enum Gender {
    MALE, FEMALE;
}
