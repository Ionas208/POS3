package at.htlkaindorf.pethome.bl;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URISyntaxException;
import java.time.LocalDate;

public class Cat extends Pet{
    private CatColor color;
    private String pictureURI;

    public Cat(String name, LocalDate dateOfBirth, Gender gender, CatColor color, String pictureURI) {
        super(name, dateOfBirth, gender);
        this.color = color;
        this.pictureURI = pictureURI;
    }

    public CatColor getColor() {
        return color;
    }

    public void setColor(CatColor color) {
        this.color = color;
    }

    public String getPictureURI() {
        return pictureURI;
    }

    public void setPictureURI(String pictureURI) {
        this.pictureURI = pictureURI;
    }

}
