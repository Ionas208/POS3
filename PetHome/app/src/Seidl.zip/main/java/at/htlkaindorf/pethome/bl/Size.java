package at.htlkaindorf.pethome.bl;

public enum Size {
    SMALL, MEDIUM, LARGE;
}