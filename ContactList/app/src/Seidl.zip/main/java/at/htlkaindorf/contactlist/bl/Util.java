package at.htlkaindorf.contactlist.bl;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Util {
    public static List<Contact> list;
    public static List<Contact> listFiltered;
    public static RecyclerView.Adapter<ContactHolder> ref;
}
